<!DOCTYPE html>
<html>
<head>
    <title>SILABTI</title>
        <!-- Latest compiled and minified CSS -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">

        <!-- Optional theme -->
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap-theme.min.css" integrity="sha384-rHyoN1iRsVXV4nD0JutlnGaslCJuC7uwjduW9SVrLvRYooPp2bWYgmgJQIXwl/Sp" crossorigin="anonymous">

        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/customlogin.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url();?>assets/css/bootstrap.css">

    <script type="text/javascript" src="<?php echo base_url();assets/js/jquery.js?>"></script>



</head>
<body>
 
    <div class="container">
        <div class="card card-container">
           
            <img id="profile-img" class="profile-img-card" src="<?php echo base_url();?>assets/gambar/logo.jpg "/>
            <p id="profile-name" class="profile-name-card">SILABTI</p>
            <form class="form-signin" method="POST" action="<?php echo base_url();?>index.php/welcome/cobainput">
                <span id="reauth-email" class="reauth-email"></span>
                <input type="email" id="inputEmail" name="email" class="form-control" placeholder="Email address" required autofocus>
                <input type="password" id="inputPassword" name="password" class="form-control" placeholder="Password" required>
                <div id="remember" class="checkbox">
                    <label>
                        <input type="checkbox" value="remember-me"> Remember me
                    </label>
                </div>
                <button class="btn btn-lg btn-primary btn-block btn-signin" type="submit">Sign in</button>
            </form><!-- /form -->

            <a href="<?php echo base_url();?>index.php/welcome/gotowelcome" class="forgot-password">

                Forgot the password?
            </a>
        </div><!-- /card-container -->
    </div><!-- /container -->


</body>
 
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
</html>